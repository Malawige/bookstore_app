package com.example.bookstore

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
