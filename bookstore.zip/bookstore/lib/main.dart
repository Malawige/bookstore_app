import 'package:flutter/material.dart';
import 'screens/book_list.dart';

void main() {
  runApp(const BookList());
}